/* -------------------------------------------------------------------------- *
 *                           MMB (MacroMoleculeBuilder)                       *
 * -------------------------------------------------------------------------- *
 *                                                                            *
 * Copyright (c) 2011-12 by the Author.                                       *
 * Author: Samuel Flores                                                      *
 *                                                                            *
 * See RNABuilder.cpp for the copyright and usage agreement.                  *
 * -------------------------------------------------------------------------- */
#include "NtCForces.h"  
#include <string.h>
#include <sstream>
#include <Utils.h>

    NTC_Torque::NTC_Torque (SimbodyMatterSubsystem& matter,ParameterReader& myParameterReader,  NTC_PAR_Class& myNTC_PAR_Class, BiopolymerClassContainer & myBiopolymerClassContainer, std::ostream& outputStream ) : matter(matter),myParameterReader(myParameterReader), myNTC_PAR_Class (myNTC_PAR_Class), myBiopolymerClassContainer(myBiopolymerClassContainer), outputStream(outputStream)
        { 
    };    
      
    void NTC_Torque::calcAxes(const State& state ,NTC_PAR_BondRow myNTC_PAR_BondRow,ResidueID residueNumber1,ResidueID residueNumber2,String chain1,String chain2,Vec3 & xAxisVector1,Vec3 & yAxisVector1, Vec3 & zAxisVector1,Vec3 & xAxisVector2,Vec3 & yAxisVector2 , Vec3 & zAxisVector2,
        Vec3 & glycosidicNitrogenAtom1LocationInGround,Vec3 & glycosidicNitrogenAtom2LocationInGround, Vec3 & ring1CenterLocationInGround, Vec3 & ring2CenterLocationInGround) const { 
      
            ResidueID myResidueID;
            ResidueID myResidueID2;
            
            myResidueID.setResidueNumber(residueNumber1.getResidueNumber()+stoi(myNTC_PAR_BondRow.atom_shift[0]));
            
            glycosidicNitrogenAtom1LocationInGround = myBiopolymerClassContainer.calcAtomLocationInGroundFrame(state,chain1,myResidueID,myNTC_PAR_BondRow.residue1Atom[0]);

            glycosidicNitrogenAtom2LocationInGround = myBiopolymerClassContainer.calcAtomLocationInGroundFrame(state,chain1,myResidueID,myNTC_PAR_BondRow.residue2Atom[0]);

            Vec3 firstRingAtomvector1 = myBiopolymerClassContainer.calcAtomLocationInGroundFrame(state,chain1,myResidueID,myNTC_PAR_BondRow.residue1Atom[0]) - glycosidicNitrogenAtom1LocationInGround;

            myResidueID.setResidueNumber(residueNumber1.getResidueNumber()+stoi(myNTC_PAR_BondRow.atom_shift[1]));            
            
            Vec3 secondRingAtomvector1 = myBiopolymerClassContainer.calcAtomLocationInGroundFrame(state,chain1,myResidueID,myNTC_PAR_BondRow.residue1Atom[1]) - glycosidicNitrogenAtom1LocationInGround;

            myResidueID.setResidueNumber(residueNumber1.getResidueNumber()+stoi(myNTC_PAR_BondRow.atom_shift[2]));             
            
            Vec3 firstRingAtomvector2 = myBiopolymerClassContainer.calcAtomLocationInGroundFrame(state,chain1,myResidueID,myNTC_PAR_BondRow.residue1Atom[2]) - glycosidicNitrogenAtom2LocationInGround;

            myResidueID.setResidueNumber(residueNumber1.getResidueNumber()+stoi(myNTC_PAR_BondRow.atom_shift[3])); 
            
            Vec3 secondRingAtomvector2 = myBiopolymerClassContainer.calcAtomLocationInGroundFrame(state,chain1,myResidueID,myNTC_PAR_BondRow.residue1Atom[3]) - glycosidicNitrogenAtom2LocationInGround;
            
            myResidueID.setResidueNumber(residueNumber1.getResidueNumber()+stoi(myNTC_PAR_BondRow.atom_shift[0]));
            myResidueID2.setResidueNumber(residueNumber1.getResidueNumber()+stoi(myNTC_PAR_BondRow.atom_shift[1]));            
            
            ring1CenterLocationInGround = (myBiopolymerClassContainer.calcAtomLocationInGroundFrame(state,chain1,myResidueID,myNTC_PAR_BondRow.residue1Atom[0])
                                              +myBiopolymerClassContainer.calcAtomLocationInGroundFrame(state,chain1,myResidueID2,myNTC_PAR_BondRow.residue1Atom[1]))/2;
                                              
            myResidueID.setResidueNumber(residueNumber1.getResidueNumber()+stoi(myNTC_PAR_BondRow.atom_shift[2]));
            myResidueID2.setResidueNumber(residueNumber1.getResidueNumber()+stoi(myNTC_PAR_BondRow.atom_shift[3]));                                               
                                              
            ring2CenterLocationInGround = (myBiopolymerClassContainer.calcAtomLocationInGroundFrame(state,chain1,myResidueID,myNTC_PAR_BondRow.residue1Atom[2])
                                              +myBiopolymerClassContainer.calcAtomLocationInGroundFrame(state,chain1,myResidueID2,myNTC_PAR_BondRow.residue1Atom[3]))/2;                                              
            
            zAxisVector1 = (firstRingAtomvector1%secondRingAtomvector1);

            zAxisVector1 = zAxisVector1/zAxisVector1.norm();

            zAxisVector2 = (firstRingAtomvector2%secondRingAtomvector2);

            zAxisVector2 = zAxisVector2/zAxisVector2.norm();

            yAxisVector1 = zAxisVector1%xAxisVector1;

            yAxisVector1= yAxisVector1/yAxisVector1.norm();

            yAxisVector2 = zAxisVector2%xAxisVector2;

            yAxisVector2= yAxisVector2/yAxisVector2.norm();                                              
                                              
    };   
    
    void NTC_Torque::calcForce(const State& state, Vector_<SpatialVec>& bodyForces,  
            Vector_<Vec3>& particleForces, Vector& mobilityForces) const 
        {  
        double energy = 0.0;        
        MobilizedBody body1;
        MobilizedBody body2;
        Transform transform1;
        Transform transform2;
        double forceConstant;
        double torqueConstant;
        double dutyCycle; //must be between 0 and 1.  at 1, force is applied all the time.  at 0, basically never applied.    
        double scrubberPeriod;
        double cutoffRadius;
        for (int r=0;r<myParameterReader.ntc_class_container.numNTC_Torsions();r++) 
        { 
	    if (myParameterReader.verbose) cout<<__FILE__<<":"<<__LINE__<<"  doing base pair #"<<r<<endl;	
        
            String chainId1=(myParameterReader.ntc_class_container.getNTC_Class(r)).NtC_FirstBPChain;            
            NTC_PAR_BondRow myNTC_PAR_BondRow = myNTC_PAR_Class.myNTC_PAR_BondMatrix.myNTC_PAR_BondRow[(myParameterReader.ntc_class_container.getNTC_Class(r)).NTC_PAR_BondRowIndex];
            String basePairIsTwoTransformForce="ntcstep";
            ResidueID residueNumber1=(myParameterReader.ntc_class_container.getNTC_Class(r).FirstBPResidue);
            ResidueID myResidueNumber;
        
            myResidueNumber.setResidueNumber(residueNumber1.getResidueNumber()+stoi(myNTC_PAR_BondRow.atom_shift[0]));        
        
            Vec3 station1 = myBiopolymerClassContainer.getAtomLocationInMobilizedBodyFrame(chainId1,myResidueNumber,myNTC_PAR_BondRow.residue1Atom[0]);        
        
            myResidueNumber.setResidueNumber(residueNumber1.getResidueNumber()+stoi(myNTC_PAR_BondRow.atom_shift[2]));        
        
            Vec3 station2 = myBiopolymerClassContainer.getAtomLocationInMobilizedBodyFrame(chainId1,myResidueNumber,myNTC_PAR_BondRow.residue1Atom[2]);

            myResidueNumber.setResidueNumber(residueNumber1.getResidueNumber()+stoi(myNTC_PAR_BondRow.atom_shift[0])); 
            
            body1 = myBiopolymerClassContainer.updAtomMobilizedBody(matter,chainId1,myResidueNumber,myNTC_PAR_BondRow.residue1Atom[0]);

            myResidueNumber.setResidueNumber(residueNumber1.getResidueNumber()+stoi(myNTC_PAR_BondRow.atom_shift[2]));            
        
            body2 = myBiopolymerClassContainer.updAtomMobilizedBody(matter,chainId1,myResidueNumber,myNTC_PAR_BondRow.residue1Atom[2]);
        
            Rotation rotation1 = Rotation(myNTC_PAR_BondRow.rotationAngle,myNTC_PAR_BondRow.rotationAxis);

            Rotation rotation2;

            rotation2.setRotationToIdentityMatrix();
            
            forceConstant = myNTC_PAR_BondRow.springConstant[0]; 
            
	        torqueConstant = myNTC_PAR_BondRow.torqueConstant;

            dutyCycle = myParameterReader.dutyCycle;
  
            if (fmod(state.getTime(),scrubberPeriod)/scrubberPeriod >= (1-dutyCycle)) 
            { 
                
            Vec3 xAxisVector1 ;
	        Vec3 yAxisVector1;
	        Vec3 zAxisVector1;
 	        Vec3 xAxisVector2;
 	        Vec3 yAxisVector2;
  	        Vec3 zAxisVector2;
            Vec3 glycosidicNitrogenAtom1LocationInGround;
            Vec3 glycosidicNitrogenAtom2LocationInGround;
            Vec3 ring1CenterLocationInGround;
            Vec3 ring2CenterLocationInGround;
            Transform myX_GB1(Vec3(0));
            Transform myX_GB2(Vec3(0));
            //{ 
                //new method that uses pre-computed corrections for topology
                
            myX_GB1 =  matter.getMobilizedBody(body1).getBodyTransform(state);
            myX_GB2 =  matter.getMobilizedBody(body2).getBodyTransform(state); 
      
            myX_GB1 = Transform(~(myParameterReader.ntc_class_container.getNTC_Class(r).rotationCorrection1*~myX_GB1.R()),myX_GB1.R()*myParameterReader.ntc_class_container.getNTC_Class(r).translationCorrection1+myX_GB1.T());
            myX_GB2 = Transform(~(myParameterReader.ntc_class_container.getNTC_Class(r).rotationCorrection2*~myX_GB2.R()),myX_GB2.R()*myParameterReader.ntc_class_container.getNTC_Class(r).translationCorrection2+myX_GB2.T());
            //}
            const Transform X_GB1 = myX_GB1;
            const Transform X_GB2 = myX_GB2;
            

            const Vec3 s1_G = X_GB1.R() * station1;
            const Vec3 s2_G = X_GB2.R() * station2;
            const Rotation rot1_G = X_GB1.R() * rotation1;
            const Rotation rot2_G = X_GB2.R() * rotation2;
            const Vec3 p1_G = X_GB1.T() + s1_G; // station measured from ground origin
            const Vec3 p2_G = X_GB2.T() + s2_G;

            const Vec3 r_G = p2_G - p1_G; // vector from point1 to point2
            const Real d   = r_G.norm();  // distance between the points
            if (myParameterReader.verbose) cout<<__FILE__<<":"<<__LINE__<<" : d         = "<<d        <<endl;	
            Real  stretch   = d ; //d - x0; // + -> tension, - -> compression
	    const Vec4 rotationAngleAxis = (rot1_G*(~rot2_G)).convertRotationToAngleAxis();	
 
            Vec3 torque;

            double myFrcScalar;
            double A, B, C;
            if (myParameterReader.verbose) cout<<__FILE__<<":"<<__LINE__<<"  myParameterReader.potentialType :"<<myParameterReader.potentialType<<endl;
            for (int i = 0; i<3; i++) torque[i] = rotationAngleAxis[i+1];

            double theta = rotationAngleAxis[0];
            torque *= -theta * torqueConstant ;
                
            myFrcScalar *= myParameterReader.twoTransformForceMultiplier;
            torque      *= myParameterReader.twoTransformForceMultiplier;

            const Real frcScalar = myFrcScalar;
            const Vec3 f1_G = (frcScalar/d) * r_G;
            
     if ((myParameterReader.potentialType).compare("HarmonicInverseLorentzian") == 0)
                {if (stretch < cutoffRadius) 
                     {
                     C =  forceConstant*cutoffRadius;
                     A = -forceConstant/2/cutoffRadius/cutoffRadius;//    -C/2/cutoffRadius/cutoffRadius/cutoffRadius;
                     B = +C/cutoffRadius-A*cutoffRadius*cutoffRadius;
                     myFrcScalar = (double)(2*A*stretch); // overall positive quantity
                     myFrcScalar += (double)(theta*theta*torqueConstant*stretch/pow((1+pow((stretch/cutoffRadius),2)),2));
                     } 
                 else {
                     C = forceConstant*cutoffRadius;  
                     myFrcScalar = (double)(-C/stretch/stretch); //overall positive quantity.  Must be positive so it points towards body 2.
                     myFrcScalar += (double)(theta*theta*torqueConstant*stretch/pow((1+pow((stretch/cutoffRadius),2)),2));
                 }
                 torque *= 1/(1+pow((stretch/cutoffRadius),2));
                }
            else if ((myParameterReader.potentialType).compare("Harmonic" ) == 0) 
                {if (stretch > cutoffRadius) stretch =  0;myFrcScalar = (double)(forceConstant*stretch);  }
            else if ((myParameterReader.potentialType).compare("HarmonicLinear" ) == 0) 
                {if (stretch > cutoffRadius) stretch =  cutoffRadius;myFrcScalar = (double)(forceConstant*stretch);  }
            else if ((myParameterReader.potentialType).compare("Inverse") == 0) 
                {if (stretch < cutoffRadius) {myFrcScalar = 0;}
                 else {double C = forceConstant*cutoffRadius;  myFrcScalar = -C/stretch/stretch; }  // C should be negatve 
                }
            else if ((myParameterReader.potentialType).compare("HarmonicInverse") == 0)
                {if (stretch < cutoffRadius) 
                     {
                      C =  forceConstant*cutoffRadius;
                      A = -forceConstant/2/cutoffRadius/cutoffRadius;//    -C/2/cutoffRadius/cutoffRadius/cutoffRadius;
                      B = +C/cutoffRadius-A*cutoffRadius*cutoffRadius;
                      if (myParameterReader.verbose) cout<< __FILE__<<":"<<__LINE__  <<" A,C :"<<A<<","<<C<<endl;
                      myFrcScalar = 2*A*stretch*(1 + theta*theta*torqueConstant/2/forceConstant);
                      torque *= (A*stretch*stretch + B) /forceConstant; //*(-torqueConstant)
                     } 
                 else {
                     C = forceConstant*cutoffRadius;  
                     myFrcScalar = -C/stretch/stretch*(1 + theta*theta*torqueConstant/2/forceConstant);
                     A =  -forceConstant/2/cutoffRadius/cutoffRadius;
                     B =  +C/cutoffRadius-A*cutoffRadius*cutoffRadius;
                     if (myParameterReader.verbose) cout<< __FILE__<<":"<<__LINE__  <<" C :"<<C<<endl;

                     torque *= (C/stretch)/forceConstant;
                 }
                 if (myParameterReader.verbose) cout<< __FILE__<<":"<<__LINE__  <<" stretch, myFrcScalar: "<<stretch<<","<<myFrcScalar<<endl;
                }
            else if ((myParameterReader.potentialType).compare("HarmonicInverseCube") == 0)
                {if (stretch < cutoffRadius) 
                     {
                      C = forceConstant*cutoffRadius*cutoffRadius*cutoffRadius;
                      A   =  -3*forceConstant/2/cutoffRadius/cutoffRadius;//    -C/2/cutoffRadius/cutoffRadius/cutoffRadius;
                      //double B =      +C/cutoffRadius-A*cutoffRadius*cutoffRadius;
                      if (myParameterReader.verbose) cout<< __FILE__<<":"<<__LINE__  <<" A,C :"<<A<<","<<C<<endl;
                      myFrcScalar = 2*A*stretch;
                     } 
                 else {
                     C = forceConstant*cutoffRadius*cutoffRadius*cutoffRadius;  myFrcScalar = -3*C/stretch/stretch/stretch/stretch;
                     if (myParameterReader.verbose) cout<< __FILE__<<":"<<__LINE__  <<" C :"<<C<<endl;
                 }
                 if (myParameterReader.verbose) cout<< __FILE__<<":"<<__LINE__  <<" stretch, myFrcScalar: "<<stretch<<","<<myFrcScalar<<endl;
                }  else {assert (0);}
                
                myFrcScalar *= myParameterReader.twoTransformForceMultiplier;
                torque      *= myParameterReader.twoTransformForceMultiplier;

            if (myParameterReader.verbose) cout<<__FILE__<<":"<<__LINE__<<" : NTC frcScalar = "<<frcScalar<<endl;	
	        if (myParameterReader.verbose) {cout<<__FILE__<<":"<<__LINE__<<"  NTC torque on body 1 ="<<torque + s1_G % f1_G<<endl;}
	        if (myParameterReader.verbose) {cout<<__FILE__<<":"<<__LINE__<<"  NTC torque on body 2 ="<<-torque - s2_G % f1_G<<endl;}            
            
            //p1_G is station measured from ground origin 
            bodyForces[body1.getMobilizedBodyIndex()] +=  SpatialVec(torque + (-(matter.getMobilizedBody(body1).getBodyTransform(state)).T()+p1_G) % f1_G, f1_G);
            bodyForces[body2.getMobilizedBodyIndex()] -=  SpatialVec(torque + (-(matter.getMobilizedBody(body2).getBodyTransform(state)).T()+p2_G) % f1_G, f1_G);
            //cout<<__FILE__<<":"<<__LINE__<<" for mobilized body index "<<body1.getMobilizedBodyIndex()<<", just added  "<< SpatialVec(torque + (-(matter.getMobilizedBody(body1).getBodyTransform(state)).T()+p1_G) % f1_G, f1_G)<<endl;
            //std::cout<<__FILE__<<":"<<__LINE__<<": getForceIsDisabled () is  "<<   isForceDisabled( state,  index)<<  std::endl;
            
            cout << " NTC FORCE " << torque + s1_G % f1_G << "  = NTC torque on body 1 " << -torque - s2_G % f1_G << " = NTC torque on body 2 " << endl;
            
            
          };
         };
        };
        
        
    Real NTC_Torque::calcPotentialEnergy(const State& state) const { 
        double energy = 0.0;         
        MobilizedBody body1;
        MobilizedBody body2;
        Transform transform1;
        Transform transform2;
        double forceConstant;
        double torqueConstant;
        double dutyCycle; //must be between 0 and 1.  at 1, force is applied all the time.  at 0, basically never applied.    
        double scrubberPeriod;
        double cutoffRadius;
        for (int r=0;r<myParameterReader.ntc_class_container.numNTC_Torsions();r++) 
        { 
	    if (myParameterReader.verbose) cout<<__FILE__<<":"<<__LINE__<<"  doing base pair #"<<r<<endl;	
        
            String chainId1=(myParameterReader.ntc_class_container.getNTC_Class(r)).NtC_FirstBPChain;            
            NTC_PAR_BondRow myNTC_PAR_BondRow = myNTC_PAR_Class.myNTC_PAR_BondMatrix.myNTC_PAR_BondRow[(myParameterReader.ntc_class_container.getNTC_Class(r)).NTC_PAR_BondRowIndex];
            String basePairIsTwoTransformForce="ntcstep";
            ResidueID residueNumber1=(myParameterReader.ntc_class_container.getNTC_Class(r).FirstBPResidue);
            ResidueID myResidueNumber;
        
            myResidueNumber.setResidueNumber(residueNumber1.getResidueNumber()+stoi(myNTC_PAR_BondRow.atom_shift[0]));        
        
            Vec3 station1 = myBiopolymerClassContainer.getAtomLocationInMobilizedBodyFrame(chainId1,myResidueNumber,myNTC_PAR_BondRow.residue1Atom[0]);        
        
            myResidueNumber.setResidueNumber(residueNumber1.getResidueNumber()+stoi(myNTC_PAR_BondRow.atom_shift[2]));        
        
            Vec3 station2 = myBiopolymerClassContainer.getAtomLocationInMobilizedBodyFrame(chainId1,myResidueNumber,myNTC_PAR_BondRow.residue1Atom[2]);

            myResidueNumber.setResidueNumber(residueNumber1.getResidueNumber()+stoi(myNTC_PAR_BondRow.atom_shift[0])); 
            
            body1 = myBiopolymerClassContainer.updAtomMobilizedBody(matter,chainId1,myResidueNumber,myNTC_PAR_BondRow.residue1Atom[0]);

            myResidueNumber.setResidueNumber(residueNumber1.getResidueNumber()+stoi(myNTC_PAR_BondRow.atom_shift[2]));            
        
            body2 = myBiopolymerClassContainer.updAtomMobilizedBody(matter,chainId1,myResidueNumber,myNTC_PAR_BondRow.residue1Atom[2]);
        
            Rotation rotation1 = Rotation(myNTC_PAR_BondRow.rotationAngle,myNTC_PAR_BondRow.rotationAxis);

            Rotation rotation2;

            rotation2.setRotationToIdentityMatrix();
            
            forceConstant = myNTC_PAR_BondRow.springConstant[0]; 
            
	        torqueConstant = myNTC_PAR_BondRow.torqueConstant;

            dutyCycle = myParameterReader.dutyCycle;
  
            if (fmod(state.getTime(),scrubberPeriod)/scrubberPeriod >= (1-dutyCycle)) 
            { 
                
            Vec3 xAxisVector1 ;
	        Vec3 yAxisVector1;
	        Vec3 zAxisVector1;
 	        Vec3 xAxisVector2;
 	        Vec3 yAxisVector2;
  	        Vec3 zAxisVector2;
            Vec3 glycosidicNitrogenAtom1LocationInGround;
            Vec3 glycosidicNitrogenAtom2LocationInGround;
            Vec3 ring1CenterLocationInGround;
            Vec3 ring2CenterLocationInGround;
            Transform myX_GB1(Vec3(0));
            Transform myX_GB2(Vec3(0));
            //{ 
                //new method that uses pre-computed corrections for topology
                
            myX_GB1 =  matter.getMobilizedBody(body1).getBodyTransform(state);
            myX_GB2 =  matter.getMobilizedBody(body2).getBodyTransform(state); 
      
            myX_GB1 = Transform(~(myParameterReader.ntc_class_container.getNTC_Class(r).rotationCorrection1*~myX_GB1.R()),myX_GB1.R()*myParameterReader.ntc_class_container.getNTC_Class(r).translationCorrection1+myX_GB1.T());
            myX_GB2 = Transform(~(myParameterReader.ntc_class_container.getNTC_Class(r).rotationCorrection2*~myX_GB2.R()),myX_GB2.R()*myParameterReader.ntc_class_container.getNTC_Class(r).translationCorrection2+myX_GB2.T());
            //}
            const Transform X_GB1 = myX_GB1;
            const Transform X_GB2 = myX_GB2;
            

            const Vec3 s1_G = X_GB1.R() * station1;
            const Vec3 s2_G = X_GB2.R() * station2;
            const Rotation rot1_G = X_GB1.R() * rotation1;
            const Rotation rot2_G = X_GB2.R() * rotation2;
            const Vec3 p1_G = X_GB1.T() + s1_G; // station measured from ground origin
            const Vec3 p2_G = X_GB2.T() + s2_G;

            const Vec3 r_G = p2_G - p1_G; // vector from point1 to point2
            const Real d   = r_G.norm();  // distance between the points
            if (myParameterReader.verbose) cout<<__FILE__<<":"<<__LINE__<<" : d         = "<<d        <<endl;	
            Real  stretch   = d ; //d - x0; // + -> tension, - -> compression
	    const Vec4 rotationAngleAxis = (rot1_G*(~rot2_G)).convertRotationToAngleAxis();	
 
            Vec3 torque;

            double myFrcScalar;
            double A, B, C;
            if (myParameterReader.verbose) cout<<__FILE__<<":"<<__LINE__<<"  myParameterReader.potentialType :"<<myParameterReader.potentialType<<endl;
            for (int i = 0; i<3; i++) torque[i] = rotationAngleAxis[i+1];

            double theta = rotationAngleAxis[0];
            torque *= -theta * torqueConstant ;
                
            myFrcScalar *= myParameterReader.twoTransformForceMultiplier;
            torque      *= myParameterReader.twoTransformForceMultiplier;

            const Real frcScalar = myFrcScalar;
            const Vec3 f1_G = (frcScalar/d) * r_G;
            
     if ((myParameterReader.potentialType).compare("HarmonicInverseLorentzian") == 0)
                {if (stretch < cutoffRadius) 
                     {
                     C =  forceConstant*cutoffRadius;
                     A = -forceConstant/2/cutoffRadius/cutoffRadius;//    -C/2/cutoffRadius/cutoffRadius/cutoffRadius;
                     B = +C/cutoffRadius-A*cutoffRadius*cutoffRadius;
                     myFrcScalar = (double)(2*A*stretch); // overall positive quantity
                     myFrcScalar += (double)(theta*theta*torqueConstant*stretch/pow((1+pow((stretch/cutoffRadius),2)),2));
                     } 
                 else {
                     C = forceConstant*cutoffRadius;  
                     myFrcScalar = (double)(-C/stretch/stretch); //overall positive quantity.  Must be positive so it points towards body 2.
                     myFrcScalar += (double)(theta*theta*torqueConstant*stretch/pow((1+pow((stretch/cutoffRadius),2)),2));
                 }
                 torque *= 1/(1+pow((stretch/cutoffRadius),2));
                }
            else if ((myParameterReader.potentialType).compare("Harmonic" ) == 0) 
                {if (stretch > cutoffRadius) stretch =  0;myFrcScalar = (double)(forceConstant*stretch);  }
            else if ((myParameterReader.potentialType).compare("HarmonicLinear" ) == 0) 
                {if (stretch > cutoffRadius) stretch =  cutoffRadius;myFrcScalar = (double)(forceConstant*stretch);  }
            else if ((myParameterReader.potentialType).compare("Inverse") == 0) 
                {if (stretch < cutoffRadius) {myFrcScalar = 0;}
                 else {double C = forceConstant*cutoffRadius;  myFrcScalar = -C/stretch/stretch; }  // C should be negatve 
                }
            else if ((myParameterReader.potentialType).compare("HarmonicInverse") == 0)
                {if (stretch < cutoffRadius) 
                     {
                      C =  forceConstant*cutoffRadius;
                      A = -forceConstant/2/cutoffRadius/cutoffRadius;//    -C/2/cutoffRadius/cutoffRadius/cutoffRadius;
                      B = +C/cutoffRadius-A*cutoffRadius*cutoffRadius;
                      if (myParameterReader.verbose) cout<< __FILE__<<":"<<__LINE__  <<" A,C :"<<A<<","<<C<<endl;
                      myFrcScalar = 2*A*stretch*(1 + theta*theta*torqueConstant/2/forceConstant);
                      torque *= (A*stretch*stretch + B) /forceConstant; //*(-torqueConstant)
                     } 
                 else {
                     C = forceConstant*cutoffRadius;  
                     myFrcScalar = -C/stretch/stretch*(1 + theta*theta*torqueConstant/2/forceConstant);
                     A =  -forceConstant/2/cutoffRadius/cutoffRadius;
                     B =  +C/cutoffRadius-A*cutoffRadius*cutoffRadius;
                     if (myParameterReader.verbose) cout<< __FILE__<<":"<<__LINE__  <<" C :"<<C<<endl;

                     torque *= (C/stretch)/forceConstant;
                 }
                 if (myParameterReader.verbose) cout<< __FILE__<<":"<<__LINE__  <<" stretch, myFrcScalar: "<<stretch<<","<<myFrcScalar<<endl;
                }
            else if ((myParameterReader.potentialType).compare("HarmonicInverseCube") == 0)
                {if (stretch < cutoffRadius) 
                     {
                      C = forceConstant*cutoffRadius*cutoffRadius*cutoffRadius;
                      A   =  -3*forceConstant/2/cutoffRadius/cutoffRadius;//    -C/2/cutoffRadius/cutoffRadius/cutoffRadius;
                      //double B =      +C/cutoffRadius-A*cutoffRadius*cutoffRadius;
                      if (myParameterReader.verbose) cout<< __FILE__<<":"<<__LINE__  <<" A,C :"<<A<<","<<C<<endl;
                      myFrcScalar = 2*A*stretch;
                     } 
                 else {
                     C = forceConstant*cutoffRadius*cutoffRadius*cutoffRadius;  myFrcScalar = -3*C/stretch/stretch/stretch/stretch;
                     if (myParameterReader.verbose) cout<< __FILE__<<":"<<__LINE__  <<" C :"<<C<<endl;
                 }
                 if (myParameterReader.verbose) cout<< __FILE__<<":"<<__LINE__  <<" stretch, myFrcScalar: "<<stretch<<","<<myFrcScalar<<endl;
                }  else {assert (0);}
                
                myFrcScalar *= myParameterReader.twoTransformForceMultiplier;
                torque      *= myParameterReader.twoTransformForceMultiplier;
            
            energy += 0.5*((rotationAngleAxis[0]*rotationAngleAxis[0]-180*180/Rad2Deg/Rad2Deg)*torqueConstant)*myParameterReader.twoTransformForceMultiplier;
            
            cout << " NTC energy = " << energy << endl;
        
            };
          };
            
        return energy; 
    };
    bool NTC_Torque::dependsOnlyOnPositions() const  { 
        return true; 
    };    
