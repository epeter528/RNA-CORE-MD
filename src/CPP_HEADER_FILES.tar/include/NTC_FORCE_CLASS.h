#ifndef NTC_FORCE_CLASS_H_
#define NTC_FORCE_CLASS_H_
#include "SimTKmolmodel.h"
#include "BiopolymerClass.h"
#include "Utils.h"          
#include "ResidueStretchContainer.h"
#include "NTC_PARAMETER_READER.h"
#include "NTC_FORCE_CLASS.h"
#include "NtC_Class_Container.h"

class MMB_EXPORT NTC_FORCE_Class {

public:

};
#endif
