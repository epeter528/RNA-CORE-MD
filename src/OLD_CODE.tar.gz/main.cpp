#include <iostream>
#include "/Users/Sam/svn/RNAToolbox/src/add.h"
int  main () {
  using namespace std;
  cout <<" 4+3 = "<<add(3,4)<<endl;
  return 0;
}
